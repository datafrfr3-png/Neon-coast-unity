using UnityEngine;

public class NeonCoastRifle : MonoBehaviour
{
    public Camera playerCamera;
    public float range = 180f;
    public float damage = 20f;
    public LayerMask hitMask = ~0;
    public void Fire()
    {
        if (playerCamera == null) playerCamera = Camera.main;
        if (playerCamera == null) return;
        Ray ray = playerCamera.ViewportPointToRay(new Vector3(.5f,.52f,0f));
        Vector3 end = ray.origin + ray.direction * range;
        if (Physics.Raycast(ray, out RaycastHit hit, range, hitMask, QueryTriggerInteraction.Ignore))
        {
            end = hit.point;
            var damageable = hit.collider.GetComponentInParent<NeonCoastDamageable>();
            if (damageable != null) damageable.ApplyDamage(damage);
        }
        GameObject tracer = new GameObject("Rifle_Tracer");
        var line = tracer.AddComponent<LineRenderer>();
        line.positionCount = 2;
        line.SetPosition(0, ray.origin);
        line.SetPosition(1, end);
        line.startWidth = .035f; line.endWidth = .008f;
        line.material = new Material(Shader.Find("Sprites/Default"));
        line.startColor = new Color(1f,.82f,.35f,1f); line.endColor = new Color(1f,.25f,.08f,0f);
        Destroy(tracer, .075f);
    }
}
