using UnityEngine;

public class NeonCoastDamageable : MonoBehaviour
{
    public float health = 100f;
    public void ApplyDamage(float amount)
    {
        health = Mathf.Max(0f, health - amount);
        if (health <= 0f) Destroy(gameObject);
    }
}
