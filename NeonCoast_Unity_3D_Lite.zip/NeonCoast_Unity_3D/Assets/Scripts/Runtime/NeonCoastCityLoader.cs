using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using UnityEngine;
using GLTFast;

public class NeonCoastCityLoader : MonoBehaviour
{
    [Header("City source")]
    public string gltfRelativePath = "CityModel/scene.gltf";
    [Range(.1f, 30f)] public float cityScale = 8f;
    public Vector3 cityRotation = Vector3.zero;
    public int maxMeshColliders = 1400;
    [Header("Player spawn")]
    public Transform player;
    public Vector3 spawnPointInCityUnits = new Vector3(24f, 22f, 0f);
    public float waterY = -1.15f;
    public bool buildProceduralFallback = true;

    GameObject cityRoot;
    public bool IsLoaded { get; private set; }

    async void Start() { await LoadCity(); }

    public async Task LoadCity()
    {
        string path = Path.Combine(Application.streamingAssetsPath, gltfRelativePath);
        if (File.Exists(path) || path.Contains("://") || path.Contains("!"))
        {
            try
            {
                var gltf = new GltfImport();
                Uri uri = new Uri(path);
                bool ok = await gltf.Load(uri);
                if (ok)
                {
                    cityRoot = new GameObject("ViceCity_Islands_3D");
                    cityRoot.transform.SetParent(transform, false);
                    cityRoot.transform.localScale = Vector3.one * cityScale;
                    cityRoot.transform.localRotation = Quaternion.Euler(cityRotation);
                    bool made = await gltf.InstantiateMainSceneAsync(cityRoot.transform);
                    if (made)
                    {
                        IsLoaded = true;
                        AddWorldColliders(cityRoot);
                        PlacePlayerOnCity();
                        CreateOcean();
                        Debug.Log("Neon Coast city model loaded successfully.");
                        return;
                    }
                }
                Debug.LogWarning("glTF load failed. Switching to procedural city fallback.");
            }
            catch (Exception e) { Debug.LogWarning("City model load error: " + e.Message); }
        }
        if (buildProceduralFallback) BuildFallbackCity();
        CreateOcean();
        PlacePlayerOnCity();
    }

    void AddWorldColliders(GameObject root)
    {
        int added = 0;
        var filters = root.GetComponentsInChildren<MeshFilter>(true);
        foreach (var mf in filters)
        {
            if (added >= maxMeshColliders) break;
            if (mf.sharedMesh == null || mf.GetComponent<Collider>() != null) continue;
            var mr = mf.GetComponent<Renderer>();
            if (mr == null) continue;
            Vector3 size = mr.bounds.size;
            if (size.x * size.y * size.z < .025f || size.magnitude < .8f) continue;
            var mc = mf.gameObject.AddComponent<MeshCollider>();
            mc.sharedMesh = mf.sharedMesh;
            mc.convex = false;
            added++;
        }
        Debug.Log("Neon Coast collision meshes: " + added);
    }

    void PlacePlayerOnCity()
    {
        if (player == null) return;
        Vector3 preferred = transform.TransformPoint(spawnPointInCityUnits * cityScale);
        Bounds worldBounds = new Bounds(preferred, new Vector3(900f, 100f, 900f));
        if (cityRoot != null)
        {
            var renderers = cityRoot.GetComponentsInChildren<Renderer>(true);
            if (renderers.Length > 0)
            {
                worldBounds = renderers[0].bounds;
                for (int i = 1; i < renderers.Length; i++) worldBounds.Encapsulate(renderers[i].bounds);
            }
        }

        float targetGround = worldBounds.min.y + Mathf.Max(1.5f, worldBounds.size.y * .12f);
        float bestScore = float.MaxValue;
        Vector3 bestPoint = preferred;
        bool found = false;
        // First try the designed start point, then sample the island footprint for a safe road/ground surface.
        List<Vector2> samples = new List<Vector2>();
        samples.Add(new Vector2(preferred.x, preferred.z));
        for (int ix = 1; ix <= 9; ix++)
        for (int iz = 1; iz <= 9; iz++)
        {
            float x = Mathf.Lerp(worldBounds.min.x + worldBounds.size.x * .08f, worldBounds.max.x - worldBounds.size.x * .08f, ix / 10f);
            float z = Mathf.Lerp(worldBounds.min.z + worldBounds.size.z * .08f, worldBounds.max.z - worldBounds.size.z * .08f, iz / 10f);
            samples.Add(new Vector2(x, z));
        }
        foreach (var sample in samples)
        {
            RaycastHit[] hits = Physics.RaycastAll(new Vector3(sample.x, worldBounds.max.y + 160f, sample.y), Vector3.down, worldBounds.size.y + 400f, ~0, QueryTriggerInteraction.Ignore);
            foreach (var hit in hits)
            {
                if (cityRoot != null && !hit.transform.IsChildOf(cityRoot.transform)) continue;
                if (hit.normal.y < .58f) continue;
                float heightPenalty = Mathf.Abs(hit.point.y - targetGround);
                float distancePenalty = Vector2.Distance(new Vector2(hit.point.x, hit.point.z), new Vector2(preferred.x, preferred.z)) * .025f;
                float score = heightPenalty + distancePenalty;
                if (score < bestScore)
                {
                    bestScore = score;
                    bestPoint = hit.point;
                    found = true;
                }
            }
        }
        player.position = found ? bestPoint + Vector3.up * 1.15f : preferred + Vector3.up * 16f;
    }

    void CreateOcean()
    {
        if (GameObject.Find("NeonCoast_Ocean") != null) return;
        var water = GameObject.CreatePrimitive(PrimitiveType.Plane);
        water.name = "NeonCoast_Ocean";
        water.transform.position = transform.position + Vector3.up * waterY * cityScale;
        water.transform.localScale = new Vector3(1500f, 1f, 1500f);
        var col = water.GetComponent<Collider>(); if (col) Destroy(col);
        var mat = new Material(Shader.Find("Standard"));
        mat.color = new Color(.035f,.26f,.38f,.9f);
        mat.SetFloat("_Glossiness", .88f);
        mat.EnableKeyword("_SPECULARHIGHLIGHTS");
        water.GetComponent<Renderer>().sharedMaterial = mat;
    }

    void BuildFallbackCity()
    {
        cityRoot = new GameObject("NeonCoast_Procedural_Fallback_City");
        cityRoot.transform.SetParent(transform, false);
        var groundMat = MakeMat(new Color(.22f,.38f,.25f),.92f);
        var roadMat = MakeMat(new Color(.12f,.14f,.17f),.9f);
        var buildingMats = new Material[] {
            MakeMat(new Color(.72f,.65f,.53f)), MakeMat(new Color(.42f,.55f,.62f)),
            MakeMat(new Color(.70f,.48f,.42f)), MakeMat(new Color(.60f,.62f,.58f))
        };
        MakeBox("Fallback_Island", new Vector3(0,-.5f,0), new Vector3(900,1,900), groundMat, cityRoot.transform, true);
        MakeBox("Main_Road_EW", new Vector3(0,.06f,0), new Vector3(850,.15f,28), roadMat, cityRoot.transform, true);
        MakeBox("Main_Road_NS", new Vector3(0,.07f,0), new Vector3(28,.15f,850), roadMat, cityRoot.transform, true);
        for(int x=-6;x<=6;x++) for(int z=-6;z<=6;z++)
        {
            if (x==0 || z==0) continue;
            float w=24+(Mathf.Abs(x*7+z*3)%12), d=22+(Mathf.Abs(x*3+z*9)%13), h=12+(Mathf.Abs(x*11+z*5)%7)*5;
            Vector3 p=new Vector3(x*58,h*.5f,z*58);
            MakeBox("City_Building",p,new Vector3(w,h,d),buildingMats[Mathf.Abs(x+z*3)%buildingMats.Length],cityRoot.transform,true);
            MakeBox("Building_Roof",p+Vector3.up*(h*.5f+.35f),new Vector3(w+1,.7f,d+1),MakeMat(new Color(.18f,.20f,.24f)),cityRoot.transform,false);
        }
        IsLoaded=true;
    }

    static Material MakeMat(Color c,float rough=.72f)
    {
        var m=new Material(Shader.Find("Standard")); m.color=c; m.SetFloat("_Glossiness",1f-rough); return m;
    }
    static GameObject MakeBox(string name,Vector3 pos,Vector3 size,Material mat,Transform parent,bool collider)
    {
        var o=GameObject.CreatePrimitive(PrimitiveType.Cube); o.name=name; o.transform.SetParent(parent,false);
        o.transform.localPosition=pos; o.transform.localScale=size; o.GetComponent<Renderer>().sharedMaterial=mat;
        if(!collider){var c=o.GetComponent<Collider>();if(c)Destroy(c);} return o;
    }
}
