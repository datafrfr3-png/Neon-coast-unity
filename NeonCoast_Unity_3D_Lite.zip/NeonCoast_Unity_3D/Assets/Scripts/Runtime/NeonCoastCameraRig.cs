using UnityEngine;

public class NeonCoastCameraRig : MonoBehaviour
{
    public Transform target;
    public float distance = 5.8f;
    public float height = 2.05f;
    public float sensitivity = 2.2f;
    public float followSmooth = 12f;
    public float pitch = 17f;
    float yaw;

    void Start()
    {
        if (target != null) yaw = target.eulerAngles.y;
    }

    void LateUpdate()
    {
        if (target == null) return;
        float dx = Input.GetAxis("Mouse X");
        float dy = Input.GetAxis("Mouse Y");
        if (NeonCoastMobileControls.Instance != null)
        {
            Vector2 look = NeonCoastMobileControls.Instance.ConsumeLookDelta();
            dx += look.x / Mathf.Max(1f, Screen.width) * 900f;
            dy += look.y / Mathf.Max(1f, Screen.height) * 700f;
        }
        yaw += dx * sensitivity;
        pitch = Mathf.Clamp(pitch - dy * sensitivity, 8f, 42f);
        Quaternion orbit = Quaternion.Euler(pitch, yaw, 0f);
        Vector3 focus = target.position + Vector3.up * height;
        Vector3 desired = focus + orbit * new Vector3(0f, 0f, -distance);
        transform.position = Vector3.Lerp(transform.position, desired, followSmooth * Time.deltaTime);
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(focus - transform.position), followSmooth * Time.deltaTime);
    }
}
