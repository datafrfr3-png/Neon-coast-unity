using UnityEngine;

public class NeonCoastMobileControls : MonoBehaviour
{
    public static NeonCoastMobileControls Instance { get; private set; }
    public NeonCoastPlayerController player;
    public bool showOnDesktop = true;
    public Vector2 MoveInput { get; private set; }
    public bool RunHeld { get; private set; }
    public Vector2 ConsumeLookDelta() { Vector2 v = lookDelta; lookDelta = Vector2.zero; return v; }

    int joystickFinger = -1;
    Vector2 joystickCenter;
    Vector2 joystickValue;
    Vector2 lookDelta;
    bool runToggle;
    static Texture2D circleTexture;

    void Awake() { Instance = this; }
    void OnDestroy() { if (Instance == this) Instance = null; }

    void Update()
    {
        if (!Application.isMobilePlatform && !showOnDesktop) return;
        MoveInput = joystickValue;
        RunHeld = runToggle;
        foreach (Touch t in Input.touches)
        {
            Vector2 p = new Vector2(t.position.x, Screen.height - t.position.y);
            if (t.phase == TouchPhase.Began)
            {
                if (p.x < Screen.width * .40f && p.y > Screen.height * .50f)
                {
                    joystickFinger = t.fingerId;
                    joystickCenter = p;
                    joystickValue = Vector2.zero;
                }
            }
            if (t.fingerId == joystickFinger)
            {
                Vector2 delta = (p - joystickCenter) / 64f;
                joystickValue = Vector2.ClampMagnitude(delta, 1f);
                if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
                {
                    joystickFinger = -1;
                    joystickValue = Vector2.zero;
                }
            }
            else if (t.phase == TouchPhase.Moved && p.x > Screen.width * .42f && p.y < Screen.height - 185f)
            {
                lookDelta += t.deltaPosition;
            }
        }
    }

    static Texture2D CreateCircleTexture()
    {
        const int size = 64;
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.wrapMode = TextureWrapMode.Clamp;
        for (int y = 0; y < size; y++) for (int x = 0; x < size; x++)
        {
            float dx = (x + .5f - size * .5f) / (size * .5f);
            float dy = (y + .5f - size * .5f) / (size * .5f);
            float d = Mathf.Sqrt(dx * dx + dy * dy);
            float a = Mathf.Clamp01((1f - d) * 18f);
            tex.SetPixel(x, y, new Color(1f, 1f, 1f, a));
        }
        tex.Apply();
        return tex;
    }

    void OnGUI()
    {
        if (!Application.isMobilePlatform && !showOnDesktop) return;
        float scale = Mathf.Clamp(Screen.width / 900f, .72f, 1.25f);
        float s = 74f * scale;
        float margin = 24f * scale;
        GUI.depth = 0;
        GUIStyle button = new GUIStyle(GUI.skin.button);
        button.fontSize = Mathf.RoundToInt(17f * scale);
        button.fontStyle = FontStyle.Bold;
        button.normal.textColor = Color.white;
        button.alignment = TextAnchor.MiddleCenter;
        Color old = GUI.color;

        Rect joy = new Rect(margin, Screen.height - s * 2.05f - margin, s * 1.75f, s * 1.75f);
        if (circleTexture == null) circleTexture = CreateCircleTexture();
        GUI.color = new Color(.08f, .10f, .14f, .48f);
        GUI.DrawTexture(joy, circleTexture);
        Vector2 handle = new Vector2(joy.center.x, joy.center.y) + joystickValue * (s * .50f);
        GUI.color = new Color(.05f, .85f, .78f, .95f);
        GUI.DrawTexture(new Rect(handle.x - s*.19f, handle.y - s*.19f, s*.38f, s*.38f), circleTexture);

        float right = Screen.width - margin - s * 1.25f;
        float bottom = Screen.height - margin;
        GUI.color = new Color(.95f, .12f, .20f, .85f);
        if (GUI.Button(new Rect(right-s*1.18f, bottom-s*.98f, s, s*.82f), "FIRE", button) && player) player.Fire();
        GUI.color = new Color(.96f, .20f, .48f, .86f);
        if (GUI.Button(new Rect(right, bottom-s*.98f, s*1.15f, s*.82f), "JUMP", button) && player) player.Jump();
        GUI.color = new Color(.22f, .48f, .62f, .78f);
        if (GUI.Button(new Rect(right, bottom-s*2.05f, s*1.15f, s*.78f), runToggle ? "RUN ON" : "RUN", button)) runToggle = !runToggle;
        GUI.color = new Color(.32f, .32f, .38f, .78f);
        if (GUI.Button(new Rect(right-s*1.18f, bottom-s*2.05f, s, s*.78f), "SIT", button) && player) player.ToggleSit();
        GUI.color = new Color(1f,1f,1f,.60f);
        GUI.Label(new Rect(margin, margin, s*3.5f, 30f), "NEON COAST  |  WASD / TOUCH");
        GUI.color = old;
    }
}
