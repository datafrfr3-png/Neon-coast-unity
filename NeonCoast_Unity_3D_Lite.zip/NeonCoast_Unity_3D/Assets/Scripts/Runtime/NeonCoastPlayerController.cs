using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class NeonCoastPlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float walkSpeed = 4.8f;
    public float runSpeed = 7.6f;
    public float jumpHeight = 1.45f;
    public float gravity = -22f;
    public float turnSpeed = 12f;
    [Header("References")]
    public Transform cameraTransform;
    public Transform visualRoot;
    public NeonCoastRifle rifle;

    CharacterController motor;
    Vector3 verticalVelocity;
    bool sitting;
    float visualBob;
    Vector3 visualScale;
    Vector3 visualPosition;

    public bool IsSitting => sitting;
    public bool IsGrounded => motor != null && motor.isGrounded;

    void Awake()
    {
        motor = GetComponent<CharacterController>();
        if (visualRoot != null)
        {
            visualScale = visualRoot.localScale;
            visualPosition = visualRoot.localPosition;
        }
    }

    void Update()
    {
        if (motor == null) return;
        Vector2 input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        bool run = Input.GetKey(KeyCode.LeftShift);

        if (NeonCoastMobileControls.Instance != null)
        {
            Vector2 touchMove = NeonCoastMobileControls.Instance.MoveInput;
            if (touchMove.sqrMagnitude > .01f) input = touchMove;
            run |= NeonCoastMobileControls.Instance.RunHeld;
        }
        input = Vector2.ClampMagnitude(input, 1f);

        if (Input.GetKeyDown(KeyCode.C)) ToggleSit();
        if (Input.GetKeyDown(KeyCode.Space)) Jump();
        if (sitting) input = Vector2.zero;

        Vector3 forward = cameraTransform ? Vector3.ProjectOnPlane(cameraTransform.forward, Vector3.up).normalized : transform.forward;
        Vector3 right = cameraTransform ? Vector3.ProjectOnPlane(cameraTransform.right, Vector3.up).normalized : transform.right;
        Vector3 move = Vector3.ClampMagnitude(right * input.x + forward * input.y, 1f);

        if (move.sqrMagnitude > .01f)
        {
            Quaternion wanted = Quaternion.LookRotation(move, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, wanted, turnSpeed * Time.deltaTime);
        }

        float speed = run ? runSpeed : walkSpeed;
        if (motor.isGrounded && verticalVelocity.y < 0f) verticalVelocity.y = -2f;
        verticalVelocity.y += gravity * Time.deltaTime;
        Vector3 velocity = move * (sitting ? 0f : speed) + Vector3.up * verticalVelocity.y;
        motor.Move(velocity * Time.deltaTime);

        // The supplied Tripo OBJ is a static mesh, not a rigged skeleton.
        // This lightweight root motion provides readable movement until a rigged FBX is supplied.
        if (visualRoot != null)
        {
            visualBob += Time.deltaTime * (run ? 13f : 9f);
            float moving = move.magnitude > .05f && motor.isGrounded ? 1f : 0f;
            float bob = Mathf.Abs(Mathf.Sin(visualBob)) * .045f * moving;
            float sitScale = sitting ? .82f : 1f;
            visualRoot.localScale = new Vector3(visualScale.x, visualScale.y * sitScale, visualScale.z);
            visualRoot.localPosition = visualPosition + Vector3.up * (bob + (sitting ? .02f : 0f));
        }
    }

    public void Jump()
    {
        if (motor != null && motor.isGrounded && !sitting)
            verticalVelocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
    }

    public void ToggleSit()
    {
        if (motor == null) return;
        sitting = !sitting;
        motor.height = sitting ? 1.05f : 1.8f;
        motor.center = new Vector3(0f, motor.height * .5f, 0f);
    }

    public void Fire()
    {
        if (rifle != null) rifle.Fire();
    }
}
