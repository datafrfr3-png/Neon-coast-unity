using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Linq;

public static class NeonCoastProjectBuilder
{
    [MenuItem("Neon Coast/Build 3D Starter Scene")]
    public static void BuildStarterScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
        RenderSettings.ambientSkyColor = new Color(.48f,.66f,.82f);
        RenderSettings.ambientEquatorColor = new Color(.42f,.48f,.50f);
        RenderSettings.ambientGroundColor = new Color(.16f,.19f,.17f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(.53f,.69f,.78f);
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogStartDistance = 500f;
        RenderSettings.fogEndDistance = 9000f;
        var sky = Shader.Find("Skybox/Procedural");
        if (sky != null) RenderSettings.skybox = new Material(sky);

        var lightObject = new GameObject("Sun_Directional_Light");
        lightObject.transform.rotation = Quaternion.Euler(42f,-28f,0f);
        var light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional; light.intensity = 1.25f; light.shadows = LightShadows.Soft;
        light.shadowStrength = .82f; light.shadowResolution = LightShadowResolution.VeryHigh;

        var fill = new GameObject("Sky_Ambient_Fill").AddComponent<Light>();
        fill.type = LightType.Directional; fill.intensity = .22f; fill.color = new Color(.55f,.72f,1f);
        fill.transform.rotation = Quaternion.Euler(20f,130f,0f);

        // Player root with a CharacterController.
        var player = new GameObject("Player_ThirdPerson");
        player.transform.position = new Vector3(0f,8f,0f);
        var cc = player.AddComponent<CharacterController>();
        cc.height = 1.8f; cc.radius = .32f; cc.center = new Vector3(0f,.9f,0f);
        cc.slopeLimit = 48f; cc.stepOffset = .32f; cc.skinWidth = .06f;

        var visual = new GameObject("Player_Visual"); visual.transform.SetParent(player.transform,false);
        string[] models = AssetDatabase.FindAssets("t:Model", new[] {"Assets/Models/Player"});
        GameObject modelPrefab = null;
        foreach (string guid in models)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (path.EndsWith(".obj")) { modelPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(path); break; }
        }
        if (modelPrefab != null)
        {
            var instance = (GameObject)PrefabUtility.InstantiatePrefab(modelPrefab);
            instance.name = "Tripo_Player_Mesh_Static";
            instance.transform.SetParent(visual.transform,false);
            var rs = instance.GetComponentsInChildren<Renderer>(true);
            if (rs.Length > 0)
            {
                Bounds b = rs[0].bounds;
                foreach (var r in rs.Skip(1)) b.Encapsulate(r.bounds);
                float factor = 1.72f / Mathf.Max(.01f,b.size.y);
                visual.transform.localScale = Vector3.one * factor;
                rs = instance.GetComponentsInChildren<Renderer>(true);
                b = rs[0].bounds; foreach(var r in rs.Skip(1)) b.Encapsulate(r.bounds);
                visual.transform.position += Vector3.up * -b.min.y;
            }
        }
        else
        {
            var body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            body.name = "Fallback_Player_Body"; body.transform.SetParent(visual.transform,false);
            body.transform.localPosition = new Vector3(0f,.9f,0f); body.transform.localScale = new Vector3(.62f,.9f,.62f);
            Object.DestroyImmediate(body.GetComponent<Collider>());
        }

        var playerController = player.AddComponent<NeonCoastPlayerController>();
        playerController.visualRoot = visual.transform;

        var rifleObject = new GameObject("Player_Rifle_System"); rifleObject.transform.SetParent(player.transform,false);
        var rifle = rifleObject.AddComponent<NeonCoastRifle>();
        playerController.rifle = rifle;

        var cameraObject = new GameObject("Main_Camera"); cameraObject.tag = "MainCamera";
        cameraObject.transform.position = new Vector3(0f,4f,-6f);
        var camera = cameraObject.AddComponent<Camera>(); camera.fieldOfView = 65f; camera.nearClipPlane=.08f; camera.farClipPlane=12000f;
        cameraObject.AddComponent<AudioListener>();
        var rig = cameraObject.AddComponent<NeonCoastCameraRig>(); rig.target = player.transform;
        playerController.cameraTransform = cameraObject.transform;
        rifle.playerCamera = camera;

        var world = new GameObject("NeonCoast_World");
        var loader = world.AddComponent<NeonCoastCityLoader>();
        loader.player = player.transform; loader.cityScale = 8f;
        loader.spawnPointInCityUnits = new Vector3(24f,20f,0f);

        var ui = new GameObject("Mobile_Touch_Controls");
        var mobile = ui.AddComponent<NeonCoastMobileControls>(); mobile.player=playerController;

        // Basic in-scene orientation marker and safe initial light.
        EditorSceneManager.SaveScene(scene,"Assets/Scenes/NeonCoast_3D_World.unity");
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene("Assets/Scenes/NeonCoast_3D_World.unity",true) };
        AssetDatabase.SaveAssets();
        Debug.Log("Neon Coast 3D starter scene saved. Press Play after city model loads.");
    }
}
