# NEON COAST — UNITY 3D STARTER PROJECT

**Target:** Unity 2022.3 LTS, Android-capable, Built-in Render Pipeline.

## Долбоорду ачуу
1. Unity Hub орнотуп, Unity Editor **2022.3 LTS** орнотуңуз.
2. Unity Hub → **Add → Add project from disk** аркылуу ушул ZIPтен чыгарылган `NeonCoast_Unity_3D` папкасын тандаңыз.
3. Unity Package Manager `com.unity.cloud.gltfast` пакетин жүктөп бүтүшүн күтүңүз (интернет керек).
4. Unity менюсунан **Neon Coast → Build 3D Starter Scene** басыңыз.
5. `Assets/Scenes/NeonCoast_3D_World.unity` сценасын ачып, **Play** басыңыз.

## Кошулган нерселер
- Мурунку иштен берилген Vice City стилиндеги 3D glTF шаар картасы жана 99 PBR түс текстурасы.
- Колдонуучу берген Tripo OBJ каарманы жана base-color / normal / roughness / metallic карталары.
- Үчүнчү жак камерасы, басуу, чуркоо, секирүү, отуруу.
- Телефон үчүн виртуалдык джойстик, камераны манжа менен буруу, Jump / Run / Sit / Fire баскычтары.
- Жөнөкөй hitscan мылтык эффекти.
- glTF карта жүктөлбөсө, иштей турган процедурдук шаар fallback.
- Карта геометриясына чектелген сан менен MeshCollider кошулат.

## Башкаруу
- WASD / жебелер: жүрүү
- Shift: чуркоо
- Space: секирүү
- C: отуруу / туруу
- Чычкан: камераны буруу
- Android: экрандагы джойстик жана аракет баскычтары

## Маанилүү чектөөлөр
- Бул — Unity үчүн **баштапкы 3D долбоор**, браузер оюнунун бардык миссиялары/машиналары/трафиги/миссия скрипттери толук көчүрүлгөн жок.
- Берилген Tripo OBJ статикалык mesh болуп көрүнөт; ал скелеттик rig/анимация бербейт. Азырынча басуудагы жеңил процедурдук кыймыл колдонулат. Толук адам анимациясы үчүн rigged FBX/GLB керек.
- Картанын масштабы 8x баштапкы glTF бирдигине коюлду. Unityде карта чыныгы көрүнүшү үчүн scale/spawn/collision жөндөөлөрүн текшерүү зарыл.
- Unity Editor бул иштөө чөйрөсүндө жок болгондуктан, проектти Unityде ачып компиляциялап же Android APK чыгарып тестирлөө мүмкүн болгон жок.
- APK чыгаруу үчүн Unity Hub'да Android Build Support, SDK/NDK жана OpenJDK модулдарын орнотуп, Build Settings → Android → Build басыңыз.

## Asset attribution
City model source: “GtaVc_Bolum_1-6 (3D/Model)” by Fakirlerin Babası, Sketchfab, CC BY 4.0.
https://sketchfab.com/3d-models/gtavc-bolum-1-6-3dmodel-0abb884e6e404c348fe60b029297692a
The original `license.txt` is included under `Assets/StreamingAssets/CityModel/`.

The player OBJ and textures were provided by the user in this conversation. Check source asset rights before public distribution.
